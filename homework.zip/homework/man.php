<?php
require_once 'human.php';

class Man extends Human
{

}