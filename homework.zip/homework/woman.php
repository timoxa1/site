<?php
require_once 'human.php';

class Woman extends Human
{

}